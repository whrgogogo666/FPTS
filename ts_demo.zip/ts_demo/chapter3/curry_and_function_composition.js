//curry
//使用普通函数实现两个函数的组合
var g = function (n) { return n + 1; };
var f = function (n) { return n * 10; };
var h = function (n) { return f(g(n)); };
// console.log('h', h(10));
//普通组合方式的缺陷：只需要一个参数，需要自己来处理参数
//高阶方式实现函数组合
var compose = function (f, g) {
    return function (v) { return f(g(v)); };
};
var h1 = compose(f, g);
// console.log('h1', h1(10));
//curry化
var add = function (x) { return function (y) { return x + y; }; };
var inc = add(1);
// console.log('inc', inc(1));
console.log('inc', inc(3));
