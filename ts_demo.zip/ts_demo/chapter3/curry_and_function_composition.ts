//@author:hairu,wu
//@fudan.edu
//curry

//使用普通函数实现两个函数的组合
const g = (n:number) => n+1
const f = (n:number) => n*10

const h = (n:number) => f(g(n))

// console.log('h', h(10));

//普通组合方式的缺陷：只需要一个参数，需要自己来处理参数


//高阶方式实现函数组合
const compose = <T1,T2,T3>(f:(v:T2)=>T3, g:(v:T1)=>T2) => 
    (v:T1)=>f(g(v))

const h1 = compose(f,g);
// console.log('h1', h1(10));



//curry化
const add = (x:number) => (y:number) => x+y
const inc = add(1);
// console.log('inc', inc(1));
// console.log('inc', inc(3));



