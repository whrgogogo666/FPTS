var data = [
    [1, 2, 3],
    [5, 2, 8, 4],
    [3]
];
var reduce = function (f, identity) {
    return function (list) {
        var acc = identity;
        for (var i = 0; i < list.length; i++) {
            acc = f(list[i], acc);
        }
        return acc;
    };
};
//sum & count
var add = function (x, y) {
    return x + y;
};
var sumF = reduce(add, 0);
var array = [1, 3, 4];
// console.log(sumF);
var countF = reduce(function (b, _) { return b + 1; }, 0);
// const forAll = <A>(pred:(a:A)=>boolean) => 
//     reduce((b:boolean,a:A)=>b && pred(a),true)
// const filter = <A>(pred:((a:A)=>Boolean)) => 
//     reduce((b:A[],a:A) => pred(a)?[...b,a]:b,[])
//首先将其累加，然后将其除以总数
var avg = function (list) {
    return list.reduce(function (a, b) { return a + b; }) / list.length;
};
// console.log('tag', avg([2,4,6]))
/**
 * redux  编程设计思想
 * redux  是js应用的一种可预测的状态容器；
 * Redux中提出了单一数据源Store 用来存储状态数据，所有的组建都可以通过Action修改Store，也可以从Store中获取最新状态。使用了redux就可以完美解决组建之间的通信问题。
 *
 * 状态容器：store 存储组件状态
 * https://segmentfault.com/a/1190000015367584
 *
 */
//OO style counter example
var Counter = /** @class */ (function () {
    function Counter() {
        this.count = 0;
    }
    Counter.prototype.inc = function () {
        this.count = this.count + 1;
    };
    Counter.prototype.dec = function () {
        this.count = this.count - 1;
    };
    Counter.prototype.getCount = function () {
        return this.count;
    };
    return Counter;
}());
var counter = new Counter();
counter.inc();
counter.inc();
//  console.log('tag', counter.getCount());
//FP style counter example
// type ActionType = "inc" | "dec"
// const reducer = (state = {count:0},action:Action<ActionType>) => {
//     switch(action.type){
//         case "inc":{
//             return {count:state.count+1};
//         }
//         case "dec":{
//             return {count:state.count-1};
//         }
//         default:{return state;}
//     }
// }
