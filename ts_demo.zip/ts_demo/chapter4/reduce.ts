//@author:hairu,wu
//@fudan.edu

const data:number[][] = [
    [1,2,3],
    [5,2,8,4],
    [3]
]


type FuncType<S,T> = (acc:S,v:T) => T

const reduce = <S,T>(f: FuncType<S,T>, identity:T) => 
    (list:S[]) => {
        var acc = identity;
        for(let i=0; i< list.length;i++){
            acc = f(list[i],acc);
        }
        return acc;
    }


//sum & count
const add = (x:number,y:number):number => {
    return x+y;
}

const sumF = reduce(add,0);
const array:Array<number> = [1,3,4];
// console.log(sumF);
const countF = reduce((b:number,_)=> b+1,0);


// const forAll = <A>(pred:(a:A)=>boolean) => 
//     reduce((b:boolean,a:A)=>b && pred(a),true)


// const filter = <A>(pred:((a:A)=>Boolean)) => 
//     reduce((b:A[],a:A) => pred(a)?[...b,a]:b,[])




//首先将其累加，然后将其除以总数
const avg = (list:number[]) => {
    return list.reduce((a,b)=>a+b) / list.length; 
}

// console.log('tag', avg([2,4,6]))




/**
 * redux  编程设计思想
 * redux  是js应用的一种可预测的状态容器；
 * Redux中提出了单一数据源Store 用来存储状态数据，所有的组建都可以通过Action修改Store，也可以从Store中获取最新状态。使用了redux就可以完美解决组建之间的通信问题。
 * 
 * 状态容器：store 存储组件状态
 * https://segmentfault.com/a/1190000015367584
 * 
 */


 //OO style counter example
 class Counter{
     count:number;
     constructor(){
         this.count = 0;
     }
     inc(){
         this.count = this.count+1;
     }
     dec(){
         this.count = this.count-1;
     }
     getCount(){
         return this.count;
     }
 }

 const counter = new Counter();
 counter.inc();
 counter.inc();
//  console.log('tag', counter.getCount());



//FP style counter example
// type ActionType = "inc" | "dec"
// const reducer = (state = {count:0},action:Action<ActionType>) => {
//     switch(action.type){
//         case "inc":{
//             return {count:state.count+1};
//         }
//         case "dec":{
//             return {count:state.count-1};
//         }
//         default:{return state;}
//     }
// }













