/**
 * case study(Maybe)
 * Category theory
 * functor
 * case study(Try)
 * Case study (Async)
 */
// OO style Maybe implementation
var Maybe = /** @class */ (function () {
    function Maybe(value) {
        this.value = value;
    }
    return Maybe;
}());
//可能返回null的函数
//   const firstChar = (s:string) => {
//       return s.length==0 ? 
//                 Maybe.none<String>():
//                 Maybe.of(s.split("")[0])
//   }
//compare with list
var inc = function (n) { return n + 1; };
var incAll = function (ints) {
    //构建一个新的容器
    var result = [];
    //将原来同期中的内容变换之后放到新的容器中
    for (var _i = 0, ints_1 = ints; _i < ints_1.length; _i++) {
        var i = ints_1[_i];
        result.push(inc(i));
    }
    return result;
};
// console.log('tag', incAll([1,2,3]));
var incAllWithMap = function (ints) {
    return ints.map(inc);
};
console.log('tag', incAllWithMap([1, 23, 4]));
