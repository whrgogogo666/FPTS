//@author:hairu,wu
//@fudan.edu
/**
 * case study(Maybe)
 * Category theory
 * functor
 * case study(Try)
 * Case study (Async)
 */

 //Maybe
 /**
  * for language like typescript ,normal type cann't
  * be null by default,if a type is actually can be null,
  * if must be declared explicitly.
  */

  type DateOrNull = Date | null
  // OO style Maybe implementation
  // class Maybe<T>{
  //     constructor(readonly value: T | null){}
  // }
  //可能返回null的函数
//   const firstChar = (s:string) => {
//       return s.length==0 ? 
//                 Maybe.none<String>():
//                 Maybe.of(s.split("")[0])
//   }


//compare with list
const inc = (n:number) => n+1

const incAll = (ints:number[]) => {
  //构建一个新的容器
  let result:number[] = []
  //将原来同期中的内容变换之后放到新的容器中
  for(let i of ints){
    result.push(inc(i));
  }
  return result;
}

// console.log('tag', incAll([1,2,3]));

const incAllWithMap = (ints:number[]) => {
  return ints.map(inc);
}
// console.log('tag', incAllWithMap([1,23,4]))


//category:类别
//catalogue:目录

//Try
// class Try<T>{
//   constructor(readonly value:
//     {type:'exception',message:string} | 
//     {type:'value',value:T}
//   ){}

//   map = <U>(f:(v:T)=>U) : Try<U> => {
//     switch(this.value.type){
//       case 'exception':
//         return Try.raise<U>(this.value.message);
//         default:return Try.of(f(this.value.value));
//     }
//   }
// }