var square = function (x) {
    return x * x;
};
var sqrt = function (x) {
    return Math.sqrt(x);
};
//过程式
var vlen_1 = function (v) {
    var sum = 0;
    for (var i = 0; i < v.length; i++) {
        sum += square(v[i]);
    }
    return sqrt(sum);
};
// console.log('tag', vlen_1([1,2,3]));
//大众函数式
var vlen_2 = function (v) {
    return sqrt(v.map(square).reduce(function (x, y) { return x + y; }));
};
// console.log('tag', vlen_2([1,2,3]));
//pure function
/*
纯函数 (Pure Function) 是 函数式编程 里面非常重要的概念 。
如果一个函数是 纯函数 (Pure Function) ，它必须符合两个条件：
返回结果只依赖于它的参数。
并且在执行过程里面没有副作用。
*/
//pure
var checkAgePure = function (minimun, age) {
    return age > minimun;
};
console.log('tag', checkAgePure(18, 20));
