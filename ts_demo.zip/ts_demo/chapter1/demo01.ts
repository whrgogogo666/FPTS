//@author:hairu,wu
//@fudan.edu

const square = (x:number) => {
    return x*x;
}

const sqrt = (x:number) => {
    return Math.sqrt(x);
}

//过程式
const vlen_1 = (v:Array<number>) => {
    let sum = 0;
    for(let i=0;i<v.length;i++){
        sum += square(v[i]);
    }
    return sqrt(sum);
}

// console.log('tag', vlen_1([1,2,3]));


//大众函数式
const vlen_2 = (v:Array<number>):number => {
   return sqrt(v.map(square).reduce((x,y) => x+y))
}

// console.log('tag', vlen_2([1,2,3]));


//pure function
/*
纯函数 (Pure Function) 是 函数式编程 里面非常重要的概念 。
如果一个函数是 纯函数 (Pure Function) ，它必须符合两个条件：
返回结果只依赖于它的参数。
并且在执行过程里面没有副作用。
*/

//pure
const checkAgePure = (minimun:number,age:number) => {
    return age>minimun;
}

// console.log('tag', checkAgePure(18,20));


//impure
interface CartItem{
    item:string,
    qunantity:number
}

const addToCartImpure = (cart:CartItem[],item:string,qunantity:number) => {
    //
    cart.push({
        item:item,
        qunantity:qunantity
    })
    return cart;
}