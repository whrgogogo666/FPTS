//定义了两个常量,匿名函数就不需要甲function了
var square = function (x) {
    return x * x;
};
var sqrt = Math.sqrt;
//过程式求向量长度
var vlen_1 = function (v) {
    var sum = 0;
    for (var i = 0; i < v.length; i++) {
        sum += square(v[i]);
    }
    return sqrt(sum);
};
console.log('过程式', vlen_1([1, 2, 3]));
//大众函数式
var vlen_2 = function (v) {
    return sqrt(v.map(square).reduce(function (x, y) {
        return x + y;
    }));
};
console.log('vlen_2', vlen_2([1, 2, 3]));
//求绝对值然后相加
var abs = Math.abs;
var add = function (x, y) {
    return x + y;
};
var abs_add = function (list) {
    return list.map(abs).reduce(add);
};
console.log('abs_add', abs_add([-1, 2, 3]));
