//箭头函数
setTimeout(function () {
    console.log('time', 1);
}, 1000);
