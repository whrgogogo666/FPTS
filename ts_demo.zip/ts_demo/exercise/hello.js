function foo(){
    console.log('hello,world', '')
}

foo();