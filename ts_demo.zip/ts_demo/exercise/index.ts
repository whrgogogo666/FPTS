//@author:hairu,wu
//@fudan.edu

console.log("你好！")

//tsc进行编译

//boolean 类型
//定义变量
var flag:boolean = true ;
// flag = "str" 错误；不可再将定义好的类型数据变为其他类型
flag = false;

//number  数字类型
var a:number = 123;
// console.log(a)

//没有对整形和浮点型进行区分，只有number 
a = 12.3;
// console.log(a)

//字符串类型:string
var str:string = "hello,whr";
console.log('str', str);

//ts 包含es5的语法，用Let或者var 都可以

//数组类型
//方式1
var arr:number[] = [1,2,3,4.5]; //定义一个number类型的数组
// console.log('arr', arr);

var arr_string:string[] = ["C++","java","python"];
// console.log('arr_string', arr_string);

//方式2
var arr_list:Array<number> = [1,2,9,4,5,6];
// console.log('arr_list', arr_list);

//元组类型,可以指定数组里面每个数据的类型
var arr_tuple:[string,number,boolean] = ["hello",12,true];
console.log('dd', arr_tuple);


//任意类型
var num_0:number = 123;
var num_1:any = "str";
console.log('num_1', num_1);
num_1 = 123.34;
console.log('num_1', num_1);

// //获取DOM节点
// var oBox:any = document.getElementById('box');
// oBox.style.color = 'red';

//空类型
var num:number;
console.log('num', num)