//@author:hairu,wu
//@fudan.edu
//函数
var getName = function(name:string, age:number):string{
    return name;
}

console.log('name', getName("小吴",18));