// var num:number;
// console.log('num', num);
// var num:undefined
// console.log('num', num)
// var num:null
// console.log('num', num)
//void 常用语方法的返回值
//es5的定义方法
// function run(){
//     console.log('run');
// }
//ts的函数
// function run():void{
//     //表示方法没有返回任何类型
//     console.log('run');
// }
// run();
//如果方法有返回值
function run() {
    return 112;
}
console.log('run', run());
