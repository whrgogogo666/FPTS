//函数
var getName = function (name, age) {
    return name;
};
console.log('name', getName("小吴", 18));
