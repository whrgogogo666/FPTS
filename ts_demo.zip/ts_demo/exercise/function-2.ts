//@author:hairu,wu
//@fudan.edu

//函数重载
//ts为了兼容es5和es6，重载和java 有区别

//传入不同的参数，结果也不同,es5中出现同名方法，下面的会替换上面的方法
// function css(config:any):any{

// }

// function css(config:any,value:any){

// }

// //ts中重载
function getInfo(name:string):string;

function getInfo(age:number):number;

function getInfo(str:any):any{
    if(typeof(str) === "string"){
        return "我叫"+str;
    }else{
        return "我的年龄是："+str;
    }
}

console.log('resule',getInfo('xiaohong'));
console.log('result-2', getInfo(12));
// console.log('result-3', getInfo(true))//根据前面声明的函数类型进行重载
