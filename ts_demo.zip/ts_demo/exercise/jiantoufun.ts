//@author:hairu,wu
//@fudan.edu

//箭头函数

//es5
setTimeout(function(){
    console.log('time', 1);
},1000);


//箭头函数里面的this指向上下文
//ts  箭头：=>
setTimeout(()=>{
    console.log('箭头函数', '这就是箭头函数，省略了函数名，多加了箭头')
},1000);

