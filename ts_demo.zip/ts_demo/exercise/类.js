//es5
//只有属性，没有方法
// function Person(){
//     this.name = 'xiaohong';
//     this.age = 12;
// }
// var person = new Person();
// console.log('person', person);
//2、构造函数和原型链里面增加方法
function Person() {
    this.name = 'xiaowu'; //属性
    this.age = 20;
    this.run = function () {
        console.log(this.name + "在跑步");
    };
}
// var person = new Person();
// person.run();
//原型链
Person.prototype.sex = 'man';
Person.prototype.work = function () {
    console.log(this.name, 'working...');
};
var person = new Person();
person.work();
