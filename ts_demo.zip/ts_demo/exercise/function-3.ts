//@author:hairu,wu
//@fudan.edu

// function getInfo1(name:string):string;

// function getInfo1(name:string,age:number):string;

// function getInfo1(name:any,age?:any):any{
//     if(age){
//         return name+":"+age;
//     }else{
//         return name+",保密";
//     }
// }

// console.log('1', getInfo1('xiaohong'));
// console.log('2', getInfo1('xiaogang',12));