/**
 * 高阶函数：函数接收一个或者多个参数，而且这个参数为函数
 * 输出一个函数，或者返回一个函数
 */
//  函数作为参数
var repeat = function (num, sth) {
    for (var i = 0; i < num; i++) {
        sth();
    }
};
var say = function () {
    console.log("hello");
};
// repeat(10,()=>{console.log("hello");});
//将函数作为返回值
var example = function () {
    return function (a, b) { return a + b; };
};
var add = example();
console.log('tag', add(1, 2));
