//@author:hairu,wu
//@fudan.edu

//es5:1.函数名定义法
// function run(){
//     return "run";
// }

//2.匿名函数
// var run2 = function(){
//     return "run";
// }

//ts中定义函数的方法
//1。：函数声明法
function run():string{
    return "run";//只可以返回string类型
}

//匿名函数法
var fun2 = function():number{
    return 123;
}

console.log('fun2', fun2());


//ts中定义方法传参
// function getInfo(name:string,age:number):string{
//     return name+'----'+age;
// }

// console.log('getInfo', getInfo("xiaowu",18));

// var getInfo = function(name:string,age:number):string{
//     return name+"---"+age;
// }

// console.log('getInfo', getInfo('xioawu',12));


//没有返回值的方法
// function say():void{
//     console.log('words:', "大家好，欢迎来到复旦大学！");
// }

// say();


//方法可选参数
//es5中的方法的实参和形参可以不一样，但是ts中必须一样，
//如果不一样，就必须配置可选参数


//可选参数必须配置到参数列表的最后
//在age参数后面加上？,表示参数可传可不传。?配置可选参数
// function getInfo(name:string,age?:number):string{
//     if(age){
//         return name+"--"+age;
//     }else{
//         return name+"--保密";
//     }
// }

// console.log('xiaowu', getInfo('小吴'));
// console.log('xiaohong', getInfo('小红',12));


//默认参数：
//es5中无法设置默认参数
//ts和es6中可以设置默认参数
// function getInfo(name:string,age:number = 20):string{
//     if(age){
//         return name+":"+age;
//     }else{
//         return name+":保密";
//     }
// }

// console.log('getInfo', getInfo('小吴'));
//剩余参数
//通过这种方式，就可以给函数传递随意数量的值，
//一个值可以，两个值也可以，三个值也可以
function sum(...result:number[]):number{
    var sum=0;
    for(var i=0;i<result.length;i++){
        sum+=result[i];
    }
    return sum;
}

console.log('sum', sum(1,2,3,4));


//比如
function getSum(a:number,b:number,...list:number[]):number{
    var sum = a+b;
    for(var i=0;i<list.length;i++){
        sum+=list[i];
    }
    return sum;
}

console.log('getSum', getSum(1,2,3,4));




