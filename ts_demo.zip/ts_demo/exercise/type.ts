//@author:hairu,wu
//@fudan.edu

// var num:number;
// console.log('num', num);

// var num:undefined
// console.log('num', num)

// var num:null
// console.log('num', num)

//void 常用语方法的返回值
//es5的定义方法
// function run(){
//     console.log('run');
// }

//ts的函数
// function run():void{
//     //表示方法没有返回任何类型
//     console.log('run');
// }

// run();


//如果方法有返回值
// function run():number{
//     return 112;
// }

// console.log('run', run());


//never 类型：是其他类型（包括null 和undefined）的子类型，代表不会出现的值
//这就意味着声明never的变量智能被never类型所赋值

