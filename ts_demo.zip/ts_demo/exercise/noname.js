//匿名函数是一个没有函数名的函数，匿名函数在程序运行时动态声明；
//除了没有函数名之外，其他的与标准函数一样。
//我们可以将匿名函数赋值给一个变量，这种表达式就成为函数表达式。
// var msg = function(){
//     return "hello,world";
// }
// console.log('msg', msg());
var res = function (a, b) {
    return a * b;
};
console.log('res', res(1, 1));
