//@author:hairu,wu
//@fudan.edu

//定义了两个常量,匿名函数就不需要甲function了
const square = (x:number) => {
    return x*x;
}

const sqrt = Math.sqrt;


//过程式求向量长度
const vlen_1 = (v:number[]) => {
    var sum = 0;
    for(var i=0;i<v.length;i++){
        sum+=square(v[i]);
    }
    return sqrt(sum);
}

console.log('过程式', vlen_1([1,2,3]));


//大众函数式
const vlen_2 = (v:number[]) => {
    return sqrt(v.map(square).reduce(
        (x:number,y:number) => {
            return x+y;
        }
    ));
}

console.log('vlen_2', vlen_2([1,2,3]));


//求绝对值然后相加
const abs = Math.abs;
const add = (x:number,y:number) => {
    return x+y;
}

const abs_add = (list:number[]) => {
    return list.map(abs).reduce(add);
}

console.log('abs_add', abs_add([-1,2,3]));