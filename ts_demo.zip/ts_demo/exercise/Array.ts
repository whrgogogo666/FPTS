//@author:hairu,wu
//@fudan.edu
var sites:string[];
sites = ["google", "baidu", "bytedance"];
// console.log('sites[0]', sites[0]);

//使用Array对象创建数组
var arr_names:number[] = new Array(4); //代销为4
for(var i=0; i<arr_names.length; i++){
    arr_names[i] = i*2;
    // console.log(i, arr_names[i]);
}


//指定元素
var arr_list = new Array();
arr_list.push("111");
arr_list.push("222");
console.log(0, arr_list[0]);

