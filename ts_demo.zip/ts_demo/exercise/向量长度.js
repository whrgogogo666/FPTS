function vlen(vec){
    //vec 为一个向量
    var sum = 0;
    for(var i = 0; i<vec.length; i++){
        sum+=vec[i]*vec[i];
    }
    return Math.sqrt(sum);
}

console.log(vlen([1,2,3]))