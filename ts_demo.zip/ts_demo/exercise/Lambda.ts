//@author:hairu,wu
//@fudan.edu
//Lambda
//省略了函数名，利用箭头 => 去代替
//用变量去接收这个函数
//不用写返回类型

// var foo = (a:number, b:number) => a+b;

// console.log('foo', foo(1,2));


var gradeTest = (grade:number) => {
    if(grade < 60){
        return "不及格";
    }else if(grade >= 90){
        return "A";
    }else{
        return "继续加油";
    }
}

console.log('gradeTest', gradeTest(100));