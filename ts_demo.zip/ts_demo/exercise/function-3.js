function getInfo1(name, age) {
    if (age) {
        return name + ":" + age;
    }
    else {
        return name + ",保密";
    }
}
console.log('1', getInfo1('xiaohong'));
console.log('2', getInfo1('xiaogang', 12));
