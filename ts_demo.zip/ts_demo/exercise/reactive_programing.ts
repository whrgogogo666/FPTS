//@author:hairu,wu
//@fudan.edu
// reactive programing
//响应式编程

//响应式编程是使用一部数据流进行编程
