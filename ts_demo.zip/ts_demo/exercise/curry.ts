//@author:hairu,wu
//@fudan.edu

/**
 * 高阶函数：函数接收一个或者多个参数，而且这个参数为函数
 * 输出一个函数，或者返回一个函数
 */

//  函数作为参数
const repeat = (num:number,sth)=>{
    for(let i=0;i<num;i++){
        sth();
    }
}

const say = ()=>{
    console.log("hello");
}

// repeat(10,()=>{console.log("hello");});

//将函数作为返回值
const example = ()=>{
    return (a:number,b:number) => a+b;
}

// const add = example();
// console.log('tag', add(1,2));


/**
 * 用大白话来说就是只传递给函数一部分参数来调用它，让它返回一个新函数去处理剩下的参数
 * 
 */

 
