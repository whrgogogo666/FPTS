//high-order functions
/**
 * Memorization
 * laziness
 * Immutability and lens     不变性和透镜
 *
 */
//implement memorization
//memeorize for single parameter
var memorize = function (func) {
    var cache = {};
    return function (v) {
        var cached = cache[v];
        return cached ? cached : cache[v] = func(v);
    };
};
//memorize for multi parameter 
//  const memorize = <T extends (...args:readonly any[]) => any>(fn:T):T => {
//      let cache:any = {};
//      return (...v:readonly any[]):any => {
//          const cached = cache[String(v)];
//          return cached?cached:(cache[String(v)] = fn(v));
//      }
//  }
var inc = function (a) { return a + 1; };
var square = function (a) { return a * a; };
//control structure
var ifElse = function (b, Then, Else) { return b ? Then : Else; };
var b = false;
var v = ifElse(b, inc(4), square(4));
console.log('tag', v);
