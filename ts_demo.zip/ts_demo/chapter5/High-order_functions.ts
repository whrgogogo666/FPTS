//@author:hairu,wu
//@fudan.edu
//high-order functions
/**
 * Memorization
 * laziness
 * Immutability and lens     不变性和透镜
 * 
 */


 //implement memorization
 //memeorize for single parameter
//  const memorize = <V,F>(func:(v:V)=>F):(v:V)=>F => {
//      let cache:any = {};
//      return (v:V)=>{
//          const cached = cache[v];
//          return cached?cached:cache[v]=func(v);
//      }
//  }

 //memorize for multi parameter 
//  const memorize = <T extends (...args:readonly any[]) => any>(fn:T):T => {
//      let cache:any = {};
//      return (...v:readonly any[]):any => {
//          const cached = cache[String(v)];
//          return cached?cached:(cache[String(v)] = fn(v));
//      }
//  }

//memorize ：缓存函数，把计算的结果，存在函数中，
// 当再次调用的时候就可以直接调用，这种方法是用空间来换取时间



const inc = (a:number) => a+1;
const square = (a:number) => a*a;
//control structure
const ifElse = <T>(b:boolean,Then:T,Else:T) => b?Then:Else
let b = false;
const v = ifElse(b,inc(4),square(4));
// console.log('tag', v);




// Laziness :infinite data
function* fib(){
    let [x,y] = [1,1];
    while(true){
        yield x;
        [x,y] = [y,x+y];
    }
}

//make abstraction
const repeat = <T>(f:(x:T)=>T, init:T) => {
    return (
        function *(){
            let cur = init;
            while(true){
                yield cur;
                cur = f(cur);
            }
        }
    );
}

//lazy:nature number generator
/**
 * 惰性函数是js函数式编程的另一个应用，惰性函数表示函数执行的分支只会在函数第一次调用的时候执行，
他的应用情景在于当我们遇到一个需要判断场景去调用不同的方法时，避免重复进入函数内的if判断，
也就是说if判断只进行一次，之后函数就会被分支里的代码替换掉
 */

 //自然数生成器




 //immutability of a object 
 /**
  * the easiest way to implement an immutable data
  * structure in typescript is to use classes and the readonly keyword:
  */

  //immutability 不变性
//   export type Street = {
//       readonly num:number;//街区号
//       readonly name:string;//街区名
//   }

//   const fudanStreet:Street = {
//       name:"handan road",
//       num:220
//   }

  class Company{
      readonly name:string;
      readonly address:Address;
  }

  class Street{
      readonly num:number
      readonly name:string
  }

  class Address{
      readonly city:string
      readonly street:Street
  }

  const company:Company = {
      name:"Ali",
      address:{
          city:"hangzhou",
          street:{
              name:"jiefangroad",
              num:300
          }
      }
  }

  //we should copy the entire object and touch the related field only
  const new_company:Company = {
      ...company,
      address:{
          ...company.address,
          street:{
              ...company.address.street,
              name:company.address.street.name.toUpperCase()
          }
      }
  }

  //dark side of immutable:they can lead to 
  //verbose:冗长的
  //and 
  //tedious:啰嗦的，冗长的，


  //solution:lenses
  /**
   * a lens is just a pair of functions that allow 
   * us to get and set a value in an object.
   * The interface of a lens could be decleared
   * as follows.
   */

//    class Lens<S,T>{
//        constructor(
//            readonly get:(object:S) => T,
//            readonly set:(object:S,value:T) => S,
//        ){}
//    }

   //we can define lens for each field of a type
//    const addressCity = new Lens<Address,string>(
//        (object:Address) => object.city,
//        (value:string,address:Address) => ({
//            ...address,
//            city:value
//        })
//    )


/**
 * Lens 最先诞生于 Haskell。它是函数式 getter 和 setter，用来处理对复杂数据集的操作
 * lens:镜头
 */

