//@author:hairu,wu
//@fudan.edu
/**
 * http://www.ruanyifeng.com/blog/2015/07/monad.html
 * 简单说，Monad就是一种设计模式，表示将一个运算过程，通过函数拆解成互相连接的多个步骤。你只要提供下一步运算所需的函数，整个运算就会自动进行下去。
 * https://github.com/wallace1/java8-and-Functional-programming/tree/master/functor1
 * 
 * https://www.cnblogs.com/tolg/p/5484076.html
 * 
 */

 /**
  * 范畴论：
  * 函子：functor
  * 单子：monad
  * 加强版函子：applicative
  * 
  * 详述：
  * 函子：functor:
  * 我们可以把函子想象成一个盒子，盒子内部封装一个值（value），不对外公布
想要处理盒子中的值，我们需要给盒子的map方法传递一个处理值得函数（纯函数），由这个函数来对值进行处理
最终map方法返回一个包含新值得盒子（函子），多次调用map方法，会形成函子嵌套
    函子表示范畴之间的映射
从上图例子来看，这两个范畴之间有映射关系，即在C1里的Int 对应在C2里的List[Int]，C1里的String对应C2里的List[String]，在C1里存在Int->String的关系态射(术语是morphism，我们可理解为函数)，在C2里也存在List[Int]->List[String]的关系态射。

换句话说，如果一个范畴内部的所有元素可以映射为另一个范畴的元素，且元素间的关系也可以映射为另一个范畴元素间关系，则认为这两个范畴之间存在映射。所谓函子就是表示两个范畴的映射。

    单子：monad

    幺半群(Monoid)
维基百科中幺半群被定义为是一个伴有二元运算的集合，且这个二元运算只需要满足结合率，并且这个集合中还必须有一个特殊的元素，幺元，对于这个二元运算，一个元素与幺元的运算将返回这个元素自身。
用公式表示为，假设这个二元运算用 * 表示:
结合律：对任何在 M 内的a、b、c ， (a * b) * c = a * (b * c) 。
单位元：存在一在 M 内的元素e，使得任一于 M 内的 a 都会符合 a * e = e * a = a 。
往往还在满足封闭性，即 a * b 的结果依然在这个集合内。

category:范畴
这个链接内容很重要！！！
http://www.ruanyifeng.com/blog/2017/02/fp-tutorial.html

  */

