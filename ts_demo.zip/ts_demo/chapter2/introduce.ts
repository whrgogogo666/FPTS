//@author:hairu,wu
//@fudan.edu
//介绍ts的一些基本语法
//主要介绍ts中类型和表达式

//algebra data type : 代数

// any 
const add = (a:any,b:any) => a+b

//build-in types
/*
number 64bit lfloating point
string 
boolean 
void return type of non-returning functions
null 
undefined value given to all uninitialized variables

*/

//如何简洁的处理null / undefined 语句
// const func = (x,y) => {
//     if(x!=null && y!=null){
//         const v = func1(x,y);
//         if(v!=null)
//             return func2(v);
//         else
//             return null;
//     }else{
//         return null;
//     }
// }


//user-defined types
//function type
//class
//interface
//type alias   :类型别名
//union type
//intersection type    : 交叉类型
//tuple type  元组类型


//named function 
const greetName = (name:string):string => {
    return "hi! "+name;
}

var Name:string = greetName("harry");

// console.log('tag', Name)



//functions with optional parameters
function buildName(firstName:string,lastName?:string){
    if(lastName)
        return firstName+" "+lastName;
    else
        return firstName;
}

let result1 = buildName("bob");
let result2 = buildName("bob", "adams")

// console.log('1', result1);
// console.log('2', result2);


//default parameters
function f(firstName?:string,lastName="smith"){
    //
    if(firstName){
        return firstName+lastName;
    }else{
        return lastName;
    }
}


// console.log('tag', f())



//Rest parameters
/*
rest parameters are treated as a boundless number of
optional parameters.
when passing arguments for a rest parameter,
you can use as many as you want;
you can even pass none;
*/

function buildName2(firstName:string, ...restOfName:string[]){
    return firstName+" "+restOfName.join(" ");
}

let employeeName = buildName2(
    "wu","hairu","harry","alisa"
);

// console.log('tag', employeeName);


//function overloading 
function test(name:string):string;
function test(age:number):number;

// function test(value:string | number):any{
//     switch(typeof value){
//         case "string":
//             return "myname is "+value;
//         case "number":
//             return value+1;
//     }
// }

function test(value:string | number):any{
    switch(typeof value){
        case "string":
            return "my name is" + value;
        case "number":
            return value+1;
    }
}

// console.log('name', test("hairu"));
// console.log('age', test(18));


//generator:发生器
//how ti iterate a container:
//iterator is a simple but important pattern,abstract
//a way the inner structure of a container

//generator versioin :javascript version:
// function * range(start,end){
//     for(let i=start;i<=end;i++){
//         yield i;
//     }
// }

// for(let i of range(1,10)){
//     console.log(i);
// }


//class
/*
inheritance
access control:default public
readonly modifier
static properties
abstract classes
using a class as an interface
*/

//typescript can be used to build applications using 
//this object-oriented approach

class Greeter{
    // greeting:string;

    constructor(readonly message:string){
        // this.greeting = message;
    }
    greet(){
        return "hello "+this.message;
    }
}

let greeter = new Greeter("world");
// console.log('tag', greeter);



//class:readonly modifer
//readonly properities must be initialized at their delearation in the constructor
class Octpus{
    readonly name:string;
    readonly numberOfLegs:number = 8;
    constructor(theName:string){
        this.name=theName;
    }
}

let panxie = new Octpus("you have 8 legs");
// console.log('tag', panxie.name);
// console.log('tag', panxie.numberOfLegs);


//interface

class Point{
    x : number;
    y : number;
}

interface Point3d extends Point{
    z: number;
}

let point3d: Point3d = {x:1, y:2, z:3};

let myPoint1:{x:number; y:number;};
let myPoint2:Point;


//aliases
type Name = string;
type NameResolver = () => string;
type NameOrResolver = Name | NameResolver;
function getName(n:NameOrResolver):Name{
    if(typeof n==="string"){
        return n;
    }else{
        return n();
    }
}

let result = getName("hello");
// console.log('tag',result);



//tuple types

/**
 * a tuple type uses an array , and (specifies)(指定) the 
 * type of elements based on their position
 */

 let poem: [number,boolean,string];
 poem = [1,true,"love"]
//  console.log('tag', poem)



//intersection type  : 交叉类型

/**
 * an intersection type combines several different types 
 * into a single supertype that includes 
 * the members from all participating types
 */

//  interface Skier{
//      slide():void;
//  }

//  interface Shooter{
//      shoot():void;
//  }

// type Biathelete = Skier & Shooter;

// let b:Biathelete;
// b.slide();
// b.shoot();


//union types
/**
 * a union type widens allowable values by specifying 
 * that the value can be of more than a single type
 */

 let union: boolean | number;
 union = 5; //ok:number
//  console.log('number', union);
 union = true;  //ok:boolean
//  console.log('string', union);
//  union = "hello";   //no



//discriminated union


type Square = {
    kind:"square";
    size:number;
}

type Rectangle = {
    kind:"rectangle";
    width:number;
    height:number;
}

type shape = Square | Rectangle;
function area(s:shape){
    if(s.kind == "square"){
        console.log('s.kind=square');
        return s.size*s.size;
    }else{
        console.log( 's.kind=rectangle');
        return s.width*s.height;
    }
}


//immutable : 不变的
//ternary


//destructing:object destructing
/**
 * destructing simply implies beadking down a 
 * complex structure into simpler parts;
 */
var rect = {x:0, y:10, width:15, height:20};
var {x,y} = rect;
// console.log(x,y);   //0 10


//destructing:array destructing
function F(){
    return [1,2];
}

var a,b;
[a,b] = F();
// console.log('a',a);
// console.log('b', b);


//Generic type
const arr_num:Array<number> = [1,2,3];
const arr_str:Array<string> = ["1","2","3"];
//polymophism  多态


//simple generic functions
const identity = <T>(v:T) => v

const log = <T>(msg:string, v:T):T => {
    console.log(msg, JSON.stringify(v));
    return v;
}

//generic function
//find first element that satisfy specific condition from a array

const findFirst = <T>(as:Array<T>, pred:(a:T) => boolean) => {
    for(let n of as){
        if(pred(n)){
            return n;
        }
    }
    return null;
}


//mapped types
//manually : 手动地

