//介绍ts的一些基本语法
//主要介绍ts中类型和表达式
var _a;
//algebra data type : 代数
// any 
var add = function (a, b) { return a + b; };
//build-in types
/*
number 64bit lfloating point
string
boolean
void return type of non-returning functions
null
undefined value given to all uninitialized variables

*/
//如何简洁的处理null / undefined 语句
// const func = (x,y) => {
//     if(x!=null && y!=null){
//         const v = func1(x,y);
//         if(v!=null)
//             return func2(v);
//         else
//             return null;
//     }else{
//         return null;
//     }
// }
//user-defined types
//function type
//class
//interface
//type alias   :类型别名
//union type
//intersection type    : 交叉类型
//tuple type  元组类型
//named function 
var greetName = function (name) {
    return "hi! " + name;
};
var Name = greetName("harry");
// console.log('tag', Name)
//functions with optional parameters
function buildName(firstName, lastName) {
    if (lastName)
        return firstName + " " + lastName;
    else
        return firstName;
}
var result1 = buildName("bob");
var result2 = buildName("bob", "adams");
// console.log('1', result1);
// console.log('2', result2);
//default parameters
function f(firstName, lastName) {
    if (lastName === void 0) { lastName = "smith"; }
    //
    if (firstName) {
        return firstName + lastName;
    }
    else {
        return lastName;
    }
}
// console.log('tag', f())
//Rest parameters
/*
rest parameters are treated as a boundless number of
optional parameters.
when passing arguments for a rest parameter,
you can use as many as you want;
you can even pass none;
*/
function buildName2(firstName) {
    var restOfName = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        restOfName[_i - 1] = arguments[_i];
    }
    return firstName + " " + restOfName.join(" ");
}
var employeeName = buildName2("wu", "hairu", "harry", "alisa");
// function test(value:string | number):any{
//     switch(typeof value){
//         case "string":
//             return "myname is "+value;
//         case "number":
//             return value+1;
//     }
// }
function test(value) {
    switch (typeof value) {
        case "string":
            return "my name is" + value;
        case "number":
            return value + 1;
    }
}
// console.log('name', test("hairu"));
// console.log('age', test(18));
//generator:发生器
//how ti iterate a container:
//iterator is a simple but important pattern,abstract
//a way the inner structure of a container
//generator versioin :javascript version:
// function * range(start,end){
//     for(let i=start;i<=end;i++){
//         yield i;
//     }
// }
// for(let i of range(1,10)){
//     console.log(i);
// }
//class
/*
inheritance
access control:default public
readonly modifier
static properties
abstract classes
using a class as an interface
*/
//typescript can be used to build applications using 
//this object-oriented approach
var Greeter = /** @class */ (function () {
    // greeting:string;
    function Greeter(message) {
        this.message = message;
        // this.greeting = message;
    }
    Greeter.prototype.greet = function () {
        return "hello " + this.message;
    };
    return Greeter;
}());
var greeter = new Greeter("world");
// console.log('tag', greeter);
//class:readonly modifer
//readonly properities must be initialized at their delearation in the constructor
var Octpus = /** @class */ (function () {
    function Octpus(theName) {
        this.numberOfLegs = 8;
        this.name = theName;
    }
    return Octpus;
}());
var panxie = new Octpus("you have 8 legs");
// console.log('tag', panxie.name);
// console.log('tag', panxie.numberOfLegs);
//interface
var Point = /** @class */ (function () {
    function Point() {
    }
    return Point;
}());
var point3d = { x: 1, y: 2, z: 3 };
var myPoint1;
var myPoint2;
function getName(n) {
    if (typeof n === "string") {
        return n;
    }
    else {
        return n();
    }
}
var result = getName("hello");
// console.log('tag',result);
//tuple types
/**
 * a tuple type uses an array , and (specifies)(指定) the
 * type of elements based on their position
 */
var poem;
poem = [1, true, "love"];
//  console.log('tag', poem)
//intersection type  : 交叉类型
/**
 * an intersection type combines several different types
 * into a single supertype that includes
 * the members from all participating types
 */
//  interface Skier{
//      slide():void;
//  }
//  interface Shooter{
//      shoot():void;
//  }
// type Biathelete = Skier & Shooter;
// let b:Biathelete;
// b.slide();
// b.shoot();
//union types
/**
 * a union type widens allowable values by specifying
 * that the value can be of more than a single type
 */
var union;
union = 5; //ok:number
//  console.log('number', union);
union = true; //ok:boolean
function area(s) {
    if (s.kind == "square") {
        console.log('s.kind=square');
        return s.size * s.size;
    }
    else {
        console.log('s.kind=rectangle');
        return s.width * s.height;
    }
}
//immutable : 不变的
//ternary
//destructing:object destructing
/**
 * destructing simply implies beadking down a
 * complex structure into simpler parts;
 */
var rect = { x: 0, y: 10, width: 15, height: 20 };
var x = rect.x, y = rect.y;
// console.log(x,y);   //0 10
//destructing:array destructing
function F() {
    return [1, 2];
}
var a, b;
_a = F(), a = _a[0], b = _a[1];
console.log('a', a);
console.log('b', b);
