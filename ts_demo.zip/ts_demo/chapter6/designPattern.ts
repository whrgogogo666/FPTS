//@author:hairu,wu
//@fudan.edu
//decorator 装饰器
//strategy
//iterator
//observer


/**
 * decorator pattern
 * the decorator pattern is a design pattern that allows behavior
 * to be added to an individual object,dynamically,
 * without affecting the behavior of other objects from the same
 * class
 */

 //OO
 //component
//  interface LabelProvider{
//      labelOf(value:any):string
//  }
//  //decorator
//  abstract class LabelDecorator implements LabelProvider {
//     constructor(protected labelProvider:LabelProvider){}
//     abstract labelOf(value:any):string;
// }

// //concreteComponent
// class NativeLabelProvider implements LabelProvider {
//     labelOf(value:any):string{
//         return value.toString();
//     }
// }

// class BraceLabelDecorator extends LabelDecorator{
//     labelOf(value:any):string{
//         return "["+this.labelProvider.labelOf(value)+"]";
//     }
// }


//FP,decorator
type labelProvider = (v:any) => string;
const nativeLabelProvider:labelProvider = (v:any) => v.toString();

const starDecorator = (lp:labelProvider) => (v:any) => lp(v)+"*";
const braceDecorator = (lp:labelProvider) => (v:any) => '['+lp(v)+"]";

// console.log('', starDecorator(nativeLabelProvider)("hello"));
// console.log('tag', braceDecorator(nativeLabelProvider)("hello"));


//strategy pattern:OO

/**
 * 从一个暑假中选取一组书，选取的 策略可能有多种，比如，可以指定作者
 * ，可以指定书名
 */

class Book{
    constructor(
        readonly title:string,
        readonly author:string
    ){}
}

//strategy
interface IBookStrategy{
    select(book:Book):boolean
}

class BookShelf{
    books:Book[] = []

    static of(books:Book[]){
        const bookShelf = new BookShelf();
        bookShelf.books = books;
        return bookShelf;
    }

    favoriteBooks(selector:IBookStrategy){
        return this.books.filter(book => selector.select(book));
    }
}

class BookOfRussell implements IBookStrategy{
    select(book:Book):boolean{
        return book.author == 'harry';
    }
}

const myFavoriteBooks = BookShelf.of(
    [
        {
            title:'moon',
            author:"harry"
        },
        {
            title:'sun',
            author:'alisa'
        }
    ]
).favoriteBooks(new BookOfRussell);

console.log('', myFavoriteBooks)




//strategy pattern:FP


 
