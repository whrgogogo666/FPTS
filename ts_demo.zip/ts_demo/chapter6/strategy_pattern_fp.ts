//@author:hairu,wu
//@fudan.edu
type Book = {
    readonly title:string,
    readonly author:string
}

const favoriteBooks = (selector:(book:Book)=>boolean,books:Book[]) => {
    return books.filter(selector);
}

const books:Book[] = [
    {
        title:"moon",
        author:"harry"
    },
    {
        title:"sun",
        author:"alisa"
    }
];

const bookOfHarry = (book:Book)=>book.author==="harry"
// console.log('', favoriteBooks(bookOfHarry,books));


//Iterator :迭代器
//Iterator:空间上的序列
//Observer:时间上的序列

/**
 * the functional world also has its own set of useful patterns ,such as
 * Chain of Operations
 * filter-map-reduce
 * memorize
 * lazy
 * lens
 * 
 */

 /**
  * FP specific patterns:
  * Functors
  * Applicatives
  * Monads
  * Monoids
  * 
  */

  
