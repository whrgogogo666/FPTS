//decorator 装饰器
//strategy
//iterator
//observer
var nativeLabelProvider = function (v) { return v.toString(); };
var starDecorator = function (lp) { return function (v) { return lp(v) + "*"; }; };
var braceDecorator = function (lp) { return function (v) { return '[' + lp(v) + "]"; }; };
// console.log('', starDecorator(nativeLabelProvider)("hello"));
// console.log('tag', braceDecorator(nativeLabelProvider)("hello"));
//strategy pattern:OO
/**
 * 从一个暑假中选取一组书，选取的 策略可能有多种，比如，可以指定作者
 * ，可以指定书名
 */
var Book = /** @class */ (function () {
    function Book(title, author) {
        this.title = title;
        this.author = author;
    }
    return Book;
}());
var BookShelf = /** @class */ (function () {
    function BookShelf() {
        this.books = [];
    }
    BookShelf.of = function (books) {
        var bookShelf = new BookShelf();
        bookShelf.books = books;
        return bookShelf;
    };
    BookShelf.prototype.favoriteBooks = function (selector) {
        return this.books.filter(function (book) { return selector.select(book); });
    };
    return BookShelf;
}());
var BookOfRussell = /** @class */ (function () {
    function BookOfRussell() {
    }
    BookOfRussell.prototype.select = function (book) {
        return book.author == 'harry';
    };
    return BookOfRussell;
}());
var myFavoriteBooks = BookShelf.of([
    {
        title: 'moon',
        author: "harry"
    },
    {
        title: 'sun',
        author: 'alisa'
    }
]).favoriteBooks(new BookOfRussell);
console.log('', myFavoriteBooks);
