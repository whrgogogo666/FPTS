var favoriteBooks = function (selector, books) {
    return books.filter(selector);
};
var books = [
    {
        title: "moon",
        author: "harry"
    },
    {
        title: "sun",
        author: "alisa"
    }
];
var bookOfHarry = function (book) { return book.author === "harry"; };
console.log('', favoriteBooks(bookOfHarry, books));
